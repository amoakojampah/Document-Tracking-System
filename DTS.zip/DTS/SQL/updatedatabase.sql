-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2021 at 12:05 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `updatedatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(10) NOT NULL,
  `file_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sender` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `letter_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `dgp_office_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `letter_date` date NOT NULL,
  `time_limit` int(10) DEFAULT NULL,
  `subject` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_id` int(11) NOT NULL,
  `status` int(1) DEFAULT 0,
  `closed_by` int(10) DEFAULT NULL,
  `closing_remark` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_type` varchar(100) CHARACTER SET latin1 NOT NULL,
  `file_loc` varchar(200) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `file_no`, `sender`, `letter_no`, `dgp_office_no`, `letter_date`, `time_limit`, `subject`, `description`, `creator_id`, `status`, `closed_by`, `closing_remark`, `file_type`, `file_loc`) VALUES
(1, '1', 'Police Headquarters Bhopal', '1', '777', '1970-01-01', 0, 'New Firewall mechanism', 'test', 1, 1, 7, 'Done Properly', 'File', '1547724953.pdf'),
(2, '12', 'Police Headquarters Bhopal', '23', 'asd', '2019-11-01', 0, 'New Firewall mechanism', 'asd', 3, 1, 7, '', 'File', '1548239448.jpg'),
(3, 'qwe', 'Police Headquarters Bhopal', '11', 'asd', '2019-11-01', 0, 'asd', 'asd', 3, 1, 8, 'wert', 'File', '1548239528.jpg'),
(4, '123', 'Police Headquarters Bhopal', '234', '345', '1970-01-01', 0, 'dfgf', 'sdffgs', 1, 0, NULL, NULL, 'File', '1548242367.jpg'),
(5, 'f-11', 'Police Headquarters Bhopal', 'l-11', '1212', '1970-01-01', 0, '-1', 'New desc', 8, 0, NULL, NULL, 'File', '1548250170.pdf'),
(6, '111', 'Police Headquarters Bhopal', '111', '111', '1970-01-01', 0, 'NEW SUB', 'desc2', 1, 0, NULL, NULL, 'File', '1548317669.jpg'),
(7, '112', 'Police Headquarters Bhopal', '112', '112', '1970-01-01', 0, 'New Sub-3', 'desc44', 1, 0, NULL, NULL, 'File', '1548317873.jpg'),
(8, '199', 'Police Headquarters Bhopal', '191', '121', '2019-02-02', 0, 'New Sub-3', '12', 8, 0, NULL, NULL, 'File', '1549032254.jpg'),
(9, '1212', 'Police Headquarters Bhopal', '1212', '1212', '2019-08-02', 0, 'asd', '121212', 8, 0, NULL, NULL, 'letter', '1549032326.jpg'),
(10, '7_2_19', 'A.tk', '7L_2k19', 'A.dgp', '2019-07-02', 0, '-1', 'file by anand', 8, 1, 7, 'Ram close File', 'File', '1549549571.jpg'),
(11, 'L-121', 'A.tk', 'L121-2', '121', '2019-09-02', 0, 'Letter121', 'letter-121', 8, 0, NULL, NULL, 'letter', '1549726803.jpg'),
(12, '9-3', 'A.tk', '3-9L', '9-3-19', '2019-09-03', 0, 'sub_of_9-3', 'upto 9-3  .11-4', 8, 0, NULL, NULL, 'letter', '1552102639.jpg'),
(13, '9-39(2)', 'A.tk', '3-9L', '9-3-19(2)', '2019-09-03', 0, 'sub_of_9-3', 'upto 9-3  .14-6', 8, 0, NULL, NULL, 'letter', '1552102792.jpg'),
(14, '9-3', 'A.tk', '3-9L', '9-3-19', '2019-10-03', 0, 'New Firewall mechanism', 'upto 9-3  .14-6', 8, 0, NULL, NULL, 'letter', '1552103625.jpg'),
(15, '9-3', 'Police Headquarters Bhopal', '3-9L', '9-3-19', '1970-01-01', 0, 'sub_of_9-3', 'upto 9-3  .11-7', 8, 0, NULL, NULL, 'letter', '1552103898.jpg'),
(16, '100256', 'Kofi', '123', 'Computer Science', '2021-01-12', 0, '-1', 'Hello', 17, 0, NULL, NULL, 'letter', '1638385386.pdf'),
(17, '3476373836', 'tony', '4465776', 'Shuga', '2021-07-12', 0, 'payment', 'rydtfhjmn', 15, 0, NULL, NULL, 'letter', '1638842467.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `notesheet`
--

CREATE TABLE `notesheet` (
  `id` int(10) NOT NULL,
  `number` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `created_by` int(10) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp(),
  `ns_loc` varchar(100) DEFAULT NULL,
  `file_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notesheet`
--

INSERT INTO `notesheet` (`id`, `number`, `subject`, `remark`, `created_by`, `date_created`, `ns_loc`, `file_id`) VALUES
(1, '1', 'Adding to new file 1', 'No remarks', 1, '2019-01-17 11:35:16', '1547724916.pdf', 2),
(2, '2', 'test notesheet', 'No remarks', 1, '2019-01-18 16:28:38', '1547828919.pdf', 2),
(3, '3', 'NOTE-1', 'remark01', 7, '2019-01-23 13:13:42', '1548249222.jpg', 5),
(4, '111', 'NOTE-2', 'REMARK02', 1, '2019-01-24 08:11:40', '1548317501.jpg', 6),
(5, '1233', 'NOTE-2', 'arter', 1, '2019-01-24 08:28:33', '1548318514.jpg', 10),
(6, '121', 'test notesheet', 'No remark 123', 1, '2019-02-03 14:55:46', '1549205746.jpg', NULL),
(7, '10_2', 'test notesheet', '10_2_ns', 8, '2019-02-10 03:26:32', '1549769193.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notesheet_transactions`
--

CREATE TABLE `notesheet_transactions` (
  `id` int(11) NOT NULL,
  `notesheet_id` int(11) DEFAULT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `dispatch_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `forward_status` int(1) NOT NULL DEFAULT 0,
  `status` int(1) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notesheet_transactions`
--

INSERT INTO `notesheet_transactions` (`id`, `notesheet_id`, `sender_id`, `receiver_id`, `dispatch_time`, `forward_status`, `status`, `remark`) VALUES
(1, 1, 1, 7, '2019-01-19 14:14:05', 0, 1, '123'),
(2, 2, 1, 5, '2019-01-19 14:22:59', 0, 1, 'No remarks'),
(3, 4, 1, 8, '2019-02-03 14:53:03', 0, 1, 'note send'),
(4, 6, 1, 8, '2019-02-03 14:56:05', 0, 1, '132'),
(5, 7, 8, 1, '2019-02-10 03:53:56', 0, 1, '10_2_remark_forward');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `file_id` int(11) DEFAULT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `dispatch_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `forward_status` int(1) NOT NULL DEFAULT 0,
  `status` int(1) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `report_time` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `type`, `file_id`, `sender_id`, `receiver_id`, `dispatch_time`, `forward_status`, `status`, `remark`, `report_time`) VALUES
(1, 'Information', 1, 1, 3, '2019-01-17 11:35:53', 2, 1, 'no remarks', '2019-02-14'),
(2, 'Information', 1, 3, 7, '2019-01-17 12:00:25', 1, 1, 'Check Updates', '2019-02-19'),
(3, 'Action', 1, 7, 5, '2019-01-17 12:02:33', 1, 1, 'Check for final updates and take actions', '2019-02-14'),
(4, 'Information', 1, 5, 7, '2019-01-17 12:04:14', 1, 1, 'You made some mistake', '2019-04-30'),
(5, 'Information', 1, 7, 3, '2019-01-17 12:05:50', 2, 1, 'tune galti ki mujhe sunna pad rha hai', '2019-02-14'),
(6, 'Action', 1, 3, 7, '2019-01-17 12:14:15', 2, 1, 'chal bhag maine koi galti nhi ki', '2019-02-19'),
(8, 'Action', 2, 3, 8, '2019-01-23 10:30:47', 0, 0, 'No remark', '2019-04-30'),
(9, 'Action', 3, 3, 8, '2019-01-23 10:32:08', 2, 1, 'asd', '2019-02-14'),
(10, 'Action', 4, 1, 3, '2019-01-23 11:19:27', 0, 1, 'No remark', '2019-02-19'),
(11, 'Information', 5, 8, 1, '2019-01-23 13:29:29', 0, 1, 'No remark', '2019-02-14'),
(12, 'Action', 6, 1, 8, '2019-01-24 08:14:29', 0, 0, 'No remark again', '2019-04-30'),
(13, 'Information', 7, 1, 8, '2019-01-24 08:17:52', 0, 1, 'run again', '2019-02-14'),
(14, 'Action', 8, 8, 1, '2019-02-01 14:44:13', 0, 1, '12', '2019-02-19'),
(15, 'Action', 9, 8, 3, '2019-02-01 14:45:26', 0, 1, '12', '2019-02-14'),
(16, 'Action', 10, 8, 5, '2019-02-07 14:26:11', 1, 1, 'Remark By Anand (Creation)', '2019-04-30'),
(17, 'Information', 10, 5, 7, '2019-02-07 14:31:15', 2, 1, 'Remark By Roshan(forward)', '2019-02-14'),
(18, 'Action', 11, 8, 1, '2019-02-09 15:40:03', 0, 0, 'run again', '2019-02-19'),
(19, 'Action', 14, 8, 1, '2019-03-09 03:53:45', 0, 1, 'remark upto 14-6', NULL),
(20, 'Action', 15, 8, 1, '2019-03-09 03:58:17', 0, 1, 'remark upto 11-7', '2019-07-11'),
(21, 'Action', 0, 7, 0, '2021-11-13 21:22:55', 0, 1, 'cvjhbjk', '0000-00-00'),
(22, 'Action', 16, 17, 15, '2021-12-01 19:03:06', 1, 1, 'Goof', '2021-12-01'),
(23, 'Information', 16, 15, 19, '2021-12-01 19:17:15', 0, 1, 'yello', '2021-12-01'),
(24, 'Action', 17, 15, 19, '2021-12-07 02:01:06', 0, 1, 'cancel', '2021-12-08');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `Department` varchar(250) NOT NULL,
  `password` varchar(50) NOT NULL,
  `office_head` varchar(250) NOT NULL,
  `role` varchar(50) NOT NULL,
  `privilage` int(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `email`, `Department`, `password`, `office_head`, `role`, `privilage`, `status`) VALUES
(10, 'Qwame', 'amoakojampah@gmail.com', '0', 'perry', '', 'Assistant Jr Registrar', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notesheet`
--
ALTER TABLE `notesheet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notesheet_transactions`
--
ALTER TABLE `notesheet_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `notesheet`
--
ALTER TABLE `notesheet`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notesheet_transactions`
--
ALTER TABLE `notesheet_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

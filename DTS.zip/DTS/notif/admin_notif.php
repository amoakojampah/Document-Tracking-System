<?php
$notif='<div class="scrollable" style="max-height: 220px">
  <ul class="list-group list-group-gap m-a-0">
    <li class="list-group-item dark-white box-shadow-z0 b">
      <span class="clear block">
        No new notifications<br>
        <small class="text-muted">Check Back Again</small>
      </span>
    </li>
  </ul>
</div>';
?>

<?php
$nav='<nav class="scroll nav-stacked nav-stacked-rounded nav-color">

  <ul class="nav" data-ui-nav>
    <li class="nav-header hidden-folded">
      <span class="text-xs">Main</span>
    </li>
    <li>
      <a href="admin.php" class="b-danger">
        <span class="nav-icon text-white no-fade">
          <i class="ion-filing"></i>
        </span>
        <span class="nav-text">Dashboard</span>
      </a>
    </li>
    <li>
      <a href="new_user.php" class="b-default">
        <span class="nav-icon text-white no-fade">
          <i class="ion-person"></i>
        </span>
        <span class="nav-text">New User</span>
      </a>
    </li>
    <li>
      <a href="settings.php" class="b-default">
        <span class="nav-icon text-white no-fade">
          <i class="fa fa-gear text-muted"></i>
        </span>
        <span class="nav-text">Settings</span>
      </a>
    </li>
  </ul>
</nav>';  ?>

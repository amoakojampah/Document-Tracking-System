<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "updateDatabase";
    
    $footer_note="Developed by IRID DEVELOPERS";
?>

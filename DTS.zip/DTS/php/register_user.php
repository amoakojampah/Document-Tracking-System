<?php
  session_start();
  if ($_SESSION["logged_in"]=="true" && $_SESSION["privilage"]=="1") {
    include("config.php");
  }
  else {
    header('location: ../index.php');
  }
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error)
  {
    die("Connection failed: " . $conn->connect_error);
  }

  $user_name="'".$_POST["user_name"]."'";
  $email="'".$_POST["email"]."'";
  $office="'".$_POST["office"]."'";
  $boss="'".$_POST["boss"]."'";
  $role="'".$_POST["role"]."'";
  $password="'".$_POST["password"]."'";

  $register_user_sql = "INSERT INTO user (user_name, email, Department, password, office_head, role, privilage, status)
                           VALUES ($user_name, $email, $office, $password, $boss, $role, '0', '1')";

  if ($conn->query($register_user_sql) === TRUE)
  {
    header("Location: ../admin.php");
  }
  else
  {
    echo "Error: " . $register_user_sql . "<br>" . $conn->error;
  }
  $conn->close();
?>
